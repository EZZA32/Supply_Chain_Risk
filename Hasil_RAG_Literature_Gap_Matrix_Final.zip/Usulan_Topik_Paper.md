# Kerangka Usulan Topik Paper — Supply Chain Risk Management

> Isi bagian dalam tanda kurung setelah memvalidasi 10 artikel dan bukti kutipan.

## Judul sementara
[Topik spesifik yang muncul dari gap terverifikasi]

## Latar belakang
[Jelaskan masalah supply chain yang nyata dan dukung dengan artikel serta halaman.]

## Research problem
[Masalah yang belum terjawab berdasarkan perbandingan beberapa artikel.]

## Research question
1. [RQ1 yang dapat dijawab dengan data/metode yang tersedia]
2. [RQ2 jika memang diperlukan]

## Research gap
- Gap 1: [pernyataan gap] — bukti: [artikel, tahun, halaman].
- Gap 2: [pernyataan gap] — bukti: [artikel, tahun, halaman].
- Gap 3: [pernyataan gap] — bukti: [artikel, tahun, halaman].

## Metode yang diusulkan
[Jelaskan dataset, variabel, metode analisis, pembanding/baseline, dan cara evaluasi.]

## Kontribusi yang diharapkan
[Kontribusi teoretis/metodologis/praktis; jangan klaim novelty sebelum verifikasi literatur.]

## Validasi sebelum dikumpulkan
- [ ] Judul, penulis, tahun, jurnal, DOI diverifikasi.
- [ ] Setiap gap didukung lebih dari satu bukti jika memungkinkan.
- [ ] Gap dibandingkan dengan semua artikel yang relevan.
- [ ] Metode dapat dijalankan dengan data dan sumber daya yang tersedia.
- [ ] Klaim kebaruan tidak berlebihan.
